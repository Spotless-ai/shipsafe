console.log('Hello from the sample project');
