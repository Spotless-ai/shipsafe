# Sample project

Synthetic ShipSafe trial. No real credentials or private files.
